<?php

namespace ClassesWithParents;

class D extends A
{
    use BTrait;
}

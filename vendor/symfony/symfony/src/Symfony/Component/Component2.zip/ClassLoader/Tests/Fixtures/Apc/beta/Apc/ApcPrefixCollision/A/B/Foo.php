<?php

class ApcPrefixCollision_A_B_Foo
{
    public static $loaded = true;
}
